package com.example.xoproject;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class start extends AppCompatActivity {
Button x,o;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start);

    }

    @Override
    protected void onStart() {
        super.onStart();
        x=((Button)findViewById(R.id.x));{
            x.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent=new Intent(start.this,MainActivity.class);
                    intent.putExtra("btn","X");
                    startActivity(intent);
                }
            });

        }
        o=((Button)findViewById(R.id.o));{
            o.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent=new Intent(start.this,MainActivity.class);
                    intent.putExtra("btn","O");
                    startActivity(intent);
                }
            });

        }
    }
}
