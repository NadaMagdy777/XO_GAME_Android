package com.example.xoproject;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class SingUP extends AppCompatActivity {
    DB_squlite dp;
    EditText name,email,pass,confirm;
    Button B1,b;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sing_u_p);
        dp=new DB_squlite(this);
        name=((EditText)findViewById(R.id.name));
        email=((EditText)findViewById(R.id.email));
        pass=((EditText)findViewById(R.id.pass));
        confirm=((EditText)findViewById(R.id.Confirm));

    }

@Override
    protected void onStart() {
    super.onStart();
    B1 = ((Button) findViewById(R.id.logup));
    {
        B1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                if ((pass.getText().toString().equals("")) || (name.getText().toString().equals("")) || (confirm.getText().toString().equals("")) || (email.getText().toString().equals(""))) {
                    Toast.makeText(SingUP.this, "Please Complete your info", Toast.LENGTH_SHORT).show();
                } else if ((pass.getText().toString()).length() <= 5) {
                    Toast.makeText(SingUP.this, "Password incorrect", Toast.LENGTH_SHORT).show();
                } else if ((name.getText().toString()).length() <= 3) {
                    Toast.makeText(SingUP.this, "UserName incorrect", Toast.LENGTH_SHORT).show();
                } else if (!(confirm.getText().toString()).equals(pass.getText().toString())) {
                    Toast.makeText(SingUP.this, "Please Confirm Your Password Correctly", Toast.LENGTH_SHORT).show();
                } else {
                    String NAME = name.getText().toString();
                    String EMAIL = email.getText().toString();
                    String PASS = pass.getText().toString();
                    Boolean RESULT = dp.insertdata(NAME, EMAIL, PASS);
                    if (RESULT) {
                        Toast.makeText(SingUP.this, "DATA insert", Toast.LENGTH_SHORT).show();

                    } else {
                        Toast.makeText(SingUP.this, "FAlse", Toast.LENGTH_SHORT).show();
                    }
                    Intent intent = new Intent(SingUP.this, start.class);
                    startActivity(intent);

                }


            }
        });
        b = ((Button) findViewById(R.id.in));
        {
            b.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent=new Intent(SingUP.this,SingIn.class);
                    startActivity(intent);

                }


            });

        }

    }
}
}
