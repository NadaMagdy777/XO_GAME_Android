package com.example.xoproject;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class SingIn extends AppCompatActivity {

    DB_squlite dp;
    EditText name,pass;
    Button b1,b2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sing_in);
        dp=new DB_squlite(this);
        name=((EditText)findViewById(R.id.Name));
        pass=((EditText)findViewById(R.id.Pass));

    }

    @Override
    protected void onStart() {
        super.onStart();
        b1 =((Button) findViewById(R.id.singup));
        {
            b1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent=new Intent(SingIn.this,SingUP.class);
                    startActivity(intent);

                    }



            });

        }
        b2=((Button)findViewById(R.id.login));
        {
            b2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String NAME=name.getText().toString();
                    String PASS=pass.getText().toString();
                    boolean check= dp.CheckUser(NAME,PASS,SingIn.this);
                    if(check){
                        Toast.makeText(SingIn.this, "login successfully", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(SingIn.this, start.class);
                        startActivity(intent);

                    }
                    else {
                        Toast.makeText(SingIn.this, "login failled", Toast.LENGTH_SHORT).show();
                    }



                }



            });

        }

    }

}
