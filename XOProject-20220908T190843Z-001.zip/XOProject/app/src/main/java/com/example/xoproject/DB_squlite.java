package com.example.xoproject;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import androidx.annotation.Nullable;

import java.util.ArrayList;

public class DB_squlite extends SQLiteOpenHelper {
    SingIn login;
    public static final String DATABASE_NAME="data.db";
    public static final String Table_Name="mytable";
    public static final String Col_1="ID";
    public static final String Col_2="username";
    public static final String Col_3="password";
    public DB_squlite(@Nullable Context context) {
        super(context, DATABASE_NAME, null, 201);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

            db.execSQL("create table mytable(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,email TEXT,pass TEXT)");


    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
       db.execSQL("DROP TABLE IF EXISTS mytable");
       onCreate(db);
    }

    public boolean insertdata(String name,String email,String pass){
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues cv=new ContentValues();
        cv.put("name",name);
        cv.put("email",email);
        cv.put("pass",pass);
        long result=db.insert("mytable",null,cv);
        if (result ==-1){
            return false;
        }
        else {return true;}

    }
    public ArrayList getALLrecord(){
        ArrayList ar=new ArrayList();
        SQLiteDatabase db=this.getReadableDatabase();
        Cursor res=db.rawQuery("select * from mytable",null);
        res.moveToFirst();
        while (res.isAfterLast()==false){
            String t1=res.getString(0);
            String t2=res.getString(1);
            String t3=res.getString(2);
            String t4=res.getString(3);
                    ar.add(t1 +"-"+t2+"-"+t3);
                    res.moveToNext();
        }
        return ar;

    }
    public boolean CheckUser(String Name,String Pass,SingIn login){
        try {
            SQLiteDatabase db=this.getReadableDatabase();
            Cursor cursor=db.rawQuery("select * from mytable where name =? and pass =? ",new String[]{Name,Pass});
            if(cursor.getCount()>0) return true;
            else return false;
        }
        catch (Exception ex){
            Toast.makeText(login,  ex.getMessage() , Toast.LENGTH_SHORT).show();
        }
        return false;

    }
    public boolean checkname(String email){
        SQLiteDatabase db=this.getReadableDatabase();
        Cursor cursor=db.rawQuery("select * from mytable where email=?",new String[]{email});
        if(cursor.getCount()>0){
            return false;
        }
        else return true;
    }
}
